// ═══════════════════════════════════════
//  API — fetch() only, no libraries
// ═══════════════════════════════════════
const API = {
  _base: 'api',
  // Token stored in localStorage, sent as get_token field in every request.
  // InfinityFree strips Authorization headers on free hosting, so we
  // include the token in the POST body or as a GET query param instead.
get _token() {
  return localStorage.getItem('arcade_token');
}
setToken(t) {
  if (t) localStorage.setItem('arcade_token', t);
  else localStorage.removeItem('arcade_token');
}
  async _call(method, file, data) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 8000);
    const headers = { 'Content-Type': 'application/json' };
    // Append token to GET urls as query param, inject into POST body
    let url = this._base + '/' + file;
    if (method === 'GET' && this._token) {
      url += (url.includes('?') ? '&' : '?') + '_token=' + encodeURIComponent(this._token);
    }
    if (method === 'POST') {
      data = Object.assign({}, data || {});
const token = this._token;
	   if (token) data._token = token;
    }
    const opts = { method, headers, signal: controller.signal };
    if (method === 'POST') opts.body = JSON.stringify(data);
    try {
      const res  = await fetch(url, opts);
      clearTimeout(timer);
      const json = await res.json();
      if (!json.ok) throw json.error || 'Something went wrong';
      return json;
    } catch(e) {
      clearTimeout(timer);
      if (e.name === 'AbortError') throw 'Server took too long to respond';
      throw e;
    }
  },
  get(file)        { return this._call('GET',  file); },
  post(file, data) { return this._call('POST', file, data); },
  session()                    { return this.get('session.php'); },
  register(u, p)               { return this.post('register.php',  { username:u, password:p }); },
  login(u, p)                  { return this.post('login.php',     { username:u, password:p }); },
  logout()                     { return this.post('logout.php'); },
  submitScore(game, score, lv) { return this.post('scores.php',    { game:game, score:score, level:lv }); },
  leaderboard(game, limit)     { return this.get('leaderboard.php?game=' + game + '&limit=' + (limit||10)); },
  profile()                    { return this.get('profile.php'); },
};

// ═══════════════════════════════════════
//  Vec2 — 2D point / direction
// ═══════════════════════════════════════
function Vec2(x, y) { this.x = x; this.y = y; }
Vec2.prototype.equals = function(v) { return this.x === v.x && this.y === v.y; };
Vec2.prototype.add    = function(v) { return new Vec2(this.x + v.x, this.y + v.y); };
Vec2.prototype.clone  = function()  { return new Vec2(this.x, this.y); };

// ═══════════════════════════════════════
//  SNAKE — Food
// ═══════════════════════════════════════
function Food(grid) {
  this.grid  = grid;
  this.pos   = new Vec2(0, 0);
  this.type  = 'normal';
  this.pulse = 0;
}
Food.prototype.randomize = function(occupied) {
  var p;
  do { p = new Vec2(Math.floor(Math.random()*this.grid), Math.floor(Math.random()*this.grid)); }
  while (occupied.some(function(o){ return o.equals(p); }));
  this.pos  = p;
  this.type = Math.random() < 0.14 ? 'bonus' : 'normal';
  this.pulse = 0;
};
Object.defineProperty(Food.prototype, 'value', { get: function(){ return this.type==='bonus'?5:1; }});
Object.defineProperty(Food.prototype, 'color', { get: function(){ return this.type==='bonus'?'#ffe600':'#ff3366'; }});

// ═══════════════════════════════════════
//  SNAKE — Snake
// ═══════════════════════════════════════
function Snake(grid) { this.grid = grid; this.reset(); }
Snake.prototype.reset = function() {
  var m = Math.floor(this.grid / 2);
  this.body    = [new Vec2(m,m), new Vec2(m-1,m), new Vec2(m-2,m)];
  this.dir     = new Vec2(1, 0);
  this.nextDir = new Vec2(1, 0);
  this.grow    = 0;
  this.alive   = true;
};
Snake.prototype.setDir = function(v) {
  if (v.x === -this.dir.x && v.y === -this.dir.y) return;
  this.nextDir = v;
};
Object.defineProperty(Snake.prototype, 'head', { get: function(){ return this.body[0]; }});
Snake.prototype.step = function() {
  this.dir = this.nextDir.clone();
  var next = this.head.add(this.dir);
  if (next.x < 0 || next.y < 0 || next.x >= this.grid || next.y >= this.grid) { this.alive = false; return false; }
  var check = this.grow > 0 ? this.body : this.body.slice(0, -1);
  if (check.some(function(s){ return s.equals(next); })) { this.alive = false; return false; }
  this.body.unshift(next);
  if (this.grow > 0) this.grow--; else this.body.pop();
  return true;
};
Snake.prototype.eat = function(n) { this.grow += n; };

// ═══════════════════════════════════════
//  SNAKE — SnakeGame
// ═══════════════════════════════════════
function SnakeGame(canvas, grid, speed) {
  this.cv        = canvas;
  this.ctx       = canvas.getContext('2d');
  this.grid      = grid;
  this.cell      = Math.floor(Math.min(canvas.width, canvas.height) / grid);
  this.baseSpeed = speed;
  this.score     = 0;
  this.level     = 1;
  this.state     = 'idle';
  this.snake     = new Snake(grid);
  this.food      = new Food(grid);
  this.food.randomize(this.snake.body);
  this.particles = [];
  this.tickAcc   = 0;
  this.lastTs    = 0;
  this._raf      = null;
  this.onScore   = null;
  this.onDead    = null;
}
Object.defineProperty(SnakeGame.prototype, 'tickMs', {
  get: function() { return Math.max(30, this.baseSpeed - (this.level-1)*8); }
});
SnakeGame.prototype.start = function() {
  this.snake.reset(); this.food.randomize(this.snake.body);
  this.score=0; this.level=1; this.particles=[]; this.tickAcc=0; this.state='running';
  if (this._raf) cancelAnimationFrame(this._raf);
  this.lastTs = performance.now(); var self = this; this._raf = requestAnimationFrame(function(t){ self._loop(t); });
};
SnakeGame.prototype.pause  = function() { if (this.state==='running') this.state='paused'; };
SnakeGame.prototype.resume = function() {
  if (this.state==='paused') { this.state='running'; this.lastTs=performance.now(); var self=this; this._raf=requestAnimationFrame(function(t){ self._loop(t); }); }
};
SnakeGame.prototype.stop     = function() { this.state='idle'; if (this._raf) cancelAnimationFrame(this._raf); };
SnakeGame.prototype.setSpeed = function(ms) { this.baseSpeed = ms; };
SnakeGame.prototype._loop = function(ts) {
  if (this.state !== 'running') return;
  this.tickAcc += ts - this.lastTs; this.lastTs = ts;
  if (this.tickAcc >= this.tickMs) { this.tickAcc=0; this._tick(); }
  this._draw();
  var self = this; this._raf = requestAnimationFrame(function(t){ self._loop(t); });
};
SnakeGame.prototype._tick = function() {
  var self = this;
  var willEat = this.snake.head.add(this.snake.dir).equals(this.food.pos);
  if (!this.snake.step()) { this.state='dead'; this._draw(); if(this.onDead) this.onDead(this.score, this.level); return; }
  if (willEat) {
    this.score += this.food.value * this.level; this.snake.eat(this.food.value);
    this._burst(this.food.pos, this.food.color); this.food.randomize(this.snake.body);
    this.level = 1 + Math.floor(this.score / 20);
    if (this.onScore) this.onScore(this.score, this.level);
  }
  this.food.pulse = (this.food.pulse + 0.15) % (Math.PI*2);
  this.particles = this.particles.filter(function(p){ return p.life > 0; });
  this.particles.forEach(function(p){ p.x+=p.vx; p.y+=p.vy; p.vy+=0.28; p.life-=3; });
};
SnakeGame.prototype._burst = function(pos, color) {
  var cx=(pos.x+.5)*this.cell, cy=(pos.y+.5)*this.cell;
  for (var i=0;i<8;i++) {
    var a=(i/8)*Math.PI*2;
    this.particles.push({x:cx,y:cy,vx:Math.cos(a)*(2+Math.random()*3),vy:Math.sin(a)*(2+Math.random()*3),color:color,life:55+Math.random()*40,size:2.5+Math.random()*3});
  }
};
SnakeGame.prototype._draw = function() {
  var ctx=this.ctx, cell=this.cell, grid=this.grid, W=grid*cell;
  ctx.clearRect(0,0,W,W);
  ctx.strokeStyle='#0d0d1a'; ctx.lineWidth=0.5;
  for (var i=0;i<=grid;i++) {
    ctx.beginPath(); ctx.moveTo(i*cell,0); ctx.lineTo(i*cell,W); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(0,i*cell); ctx.lineTo(W,i*cell); ctx.stroke();
  }
  var fp=this.food.pos, pls=1+Math.sin(this.food.pulse)*0.11;
  var fr=cell*0.37*pls, fcx=(fp.x+0.5)*cell, fcy=(fp.y+0.5)*cell;
  ctx.save(); ctx.shadowColor=this.food.color; ctx.shadowBlur=13; ctx.fillStyle=this.food.color;
  ctx.beginPath(); ctx.arc(fcx,fcy,fr,0,Math.PI*2); ctx.fill();
  if (this.food.type==='bonus') {
    ctx.fillStyle='#000'; ctx.font='bold '+Math.floor(cell*0.42)+'px Share Tech Mono';
    ctx.textAlign='center'; ctx.textBaseline='middle'; ctx.fillText('\u2605',fcx,fcy);
  }
  ctx.restore();
  var segs=this.snake.body;
  for (var i=segs.length-1;i>=0;i--) {
    var s=segs[i], t=i/segs.length, g=Math.floor(255*(1-t*0.6));
    ctx.save(); ctx.shadowColor='#00ff88'; ctx.shadowBlur=i===0?15:5;
    ctx.fillStyle=i===0?'#fff':'rgba(0,'+g+','+Math.floor(g*0.5)+','+(0.5+(1-t)*0.5)+')';
    var pad=2,rx=s.x*cell+pad,ry=s.y*cell+pad,rw=cell-pad*2,r=4;
    ctx.beginPath(); ctx.moveTo(rx+r,ry); ctx.lineTo(rx+rw-r,ry);
    ctx.arcTo(rx+rw,ry,rx+rw,ry+r,r); ctx.lineTo(rx+rw,ry+rw-r);
    ctx.arcTo(rx+rw,ry+rw,rx+rw-r,ry+rw,r); ctx.lineTo(rx+r,ry+rw);
    ctx.arcTo(rx,ry+rw,rx,ry+rw-r,r); ctx.lineTo(rx,ry+r);
    ctx.arcTo(rx,ry,rx+r,ry,r); ctx.closePath(); ctx.fill(); ctx.restore();
    if (i===0) {
      ctx.fillStyle='#000'; var d=this.snake.dir;
      var eyes=[[d.y*4-d.x*2, d.x*4-d.y*2],[-d.y*4-d.x*2,-d.x*4-d.y*2]];
      for (var e=0;e<eyes.length;e++) {
        ctx.beginPath(); ctx.arc(s.x*cell+cell/2+eyes[e][0]+d.x*3, s.y*cell+cell/2+eyes[e][1]+d.y*3, 2, 0, Math.PI*2); ctx.fill();
      }
    }
  }
  this.particles.forEach(function(p){
    ctx.save(); ctx.globalAlpha=p.life/100; ctx.fillStyle=p.color; ctx.shadowColor=p.color; ctx.shadowBlur=7;
    ctx.beginPath(); ctx.arc(p.x,p.y,p.size,0,Math.PI*2); ctx.fill(); ctx.restore();
  });
};

// ═══════════════════════════════════════
//  FLAPPY BIRD — FlappyGame
// ═══════════════════════════════════════
function FlappyGame(canvas) {
  this.cv    = canvas;
  this.ctx   = canvas.getContext('2d');
  this.W     = canvas.width;
  this.H     = canvas.height;
  this.state = 'idle';
  this.score = 0;
  this._raf  = null;
  this.onScore = null;
  this.onDead  = null;
  this._init();
}
FlappyGame.prototype._init = function() {
  this.bird      = { x: this.W*0.25, y: this.H/2, vy: 0, r: 14 };
  this.pipes     = [];
  this.particles = [];
  this.pipeTimer = 0;
  this.score     = 0;
  this.speed     = 2.2;
};
FlappyGame.prototype.start = function() {
  this._init(); this.state='running';
  if (this._raf) cancelAnimationFrame(this._raf);
  var self=this; this._raf=requestAnimationFrame(function(){ self._loop(); });
};
FlappyGame.prototype.pause  = function() { if (this.state==='running') this.state='paused'; };
FlappyGame.prototype.resume = function() {
  if (this.state==='paused') { this.state='running'; var self=this; this._raf=requestAnimationFrame(function(){ self._loop(); }); }
};
FlappyGame.prototype.stop  = function() { this.state='idle'; if (this._raf) cancelAnimationFrame(this._raf); };
FlappyGame.prototype.flap  = function() { if (this.state==='running') this.bird.vy=-7; };
FlappyGame.prototype._loop = function() {
  if (this.state !== 'running') return;
  this._tick(); this._draw();
  var self=this; this._raf=requestAnimationFrame(function(){ self._loop(); });
};
FlappyGame.prototype._tick = function() {
  var b=this.bird;
  b.vy += 0.38; b.y += b.vy;
  if (b.y-b.r <= 0 || b.y+b.r >= this.H) { this.state='dead'; if(this.onDead) this.onDead(this.score,1); return; }
  this.pipeTimer++;
  if (this.pipeTimer > 90) {
    this.pipeTimer=0;
    var gap=130, top=60+Math.random()*(this.H-gap-120);
    this.pipes.push({x:this.W, top:top, gap:gap, scored:false});
  }
  this.speed = 2.2 + this.score*0.08;
  for (var i=0;i<this.pipes.length;i++) this.pipes[i].x -= this.speed;
  this.pipes = this.pipes.filter(function(p){ return p.x > -60; });
  for (var i=0;i<this.pipes.length;i++) {
    var p=this.pipes[i];
    if (!p.scored && p.x+52 < b.x) {
      p.scored=true; this.score++;
      if (this.onScore) this.onScore(this.score,1);
      this._burst(b.x, b.y, '#ff9500');
    }
    if (b.x+b.r > p.x+8 && b.x-b.r < p.x+52) {
      if (b.y-b.r < p.top || b.y+b.r > p.top+p.gap) { this.state='dead'; if(this.onDead) this.onDead(this.score,1); return; }
    }
  }
  this.particles = this.particles.filter(function(p){ return p.life>0; });
  this.particles.forEach(function(p){ p.x+=p.vx; p.y+=p.vy; p.vy+=0.2; p.life-=4; });
};
FlappyGame.prototype._burst = function(x,y,color) {
  for (var i=0;i<6;i++) {
    var a=(i/6)*Math.PI*2;
    this.particles.push({x:x,y:y,vx:Math.cos(a)*3,vy:Math.sin(a)*3,color:color,life:50,size:3});
  }
};
FlappyGame.prototype._draw = function() {
  var ctx=this.ctx, W=this.W, H=this.H;
  var sky=ctx.createLinearGradient(0,0,0,H);
  sky.addColorStop(0,'#060614'); sky.addColorStop(1,'#0a0a1a');
  ctx.fillStyle=sky; ctx.fillRect(0,0,W,H);
  for (var i=0;i<this.pipes.length;i++) {
    var p=this.pipes[i];
    ctx.fillStyle='#1a3a1a'; ctx.strokeStyle='#00ff8844'; ctx.lineWidth=1;
    ctx.fillRect(p.x+8,0,44,p.top); ctx.strokeRect(p.x+8,0,44,p.top);
    ctx.fillStyle='#1f4a1f'; ctx.fillRect(p.x+4,p.top-12,52,12);
    ctx.fillStyle='#1a3a1a';
    ctx.fillRect(p.x+8,p.top+p.gap,44,H-p.top-p.gap);
    ctx.strokeRect(p.x+8,p.top+p.gap,44,H-p.top-p.gap);
    ctx.fillStyle='#1f4a1f'; ctx.fillRect(p.x+4,p.top+p.gap,52,12);
  }
  var b=this.bird, angle=Math.min(Math.max(b.vy*0.06,-0.4),0.8);
  ctx.save(); ctx.translate(b.x,b.y); ctx.rotate(angle);
  ctx.shadowColor='#ff9500'; ctx.shadowBlur=12; ctx.fillStyle='#ff9500';
  ctx.beginPath(); ctx.arc(0,0,b.r,0,Math.PI*2); ctx.fill();
  ctx.fillStyle='#ffb833'; ctx.beginPath(); ctx.ellipse(-4,2,8,5,-0.3,0,Math.PI*2); ctx.fill();
  ctx.shadowBlur=0; ctx.fillStyle='#fff'; ctx.beginPath(); ctx.arc(5,-4,4,0,Math.PI*2); ctx.fill();
  ctx.fillStyle='#000'; ctx.beginPath(); ctx.arc(6,-4,2,0,Math.PI*2); ctx.fill();
  ctx.fillStyle='#ff6600'; ctx.beginPath(); ctx.moveTo(12,-1); ctx.lineTo(18,1); ctx.lineTo(12,3); ctx.closePath(); ctx.fill();
  ctx.restore();
  var self=this;
  this.particles.forEach(function(p){
    ctx.save(); ctx.globalAlpha=p.life/50; ctx.fillStyle=p.color; ctx.shadowColor=p.color; ctx.shadowBlur=6;
    ctx.beginPath(); ctx.arc(p.x,p.y,p.size,0,Math.PI*2); ctx.fill(); ctx.restore();
  });
  ctx.fillStyle='#ffffff33'; ctx.font="12px 'Press Start 2P',monospace"; ctx.textAlign='center';
  ctx.fillText(this.score, W/2, 30);
};

// ═══════════════════════════════════════
//  DINO RUN — DinoGame
// ═══════════════════════════════════════
function DinoGame(canvas) {
  this.cv     = canvas;
  this.ctx    = canvas.getContext('2d');
  this.W      = canvas.width;
  this.H      = canvas.height;
  this.ground = this.H - 50;
  this.state  = 'idle';
  this.score  = 0;
  this._raf   = null;
  this.onScore = null;
  this.onDead  = null;
  this._init();
}
DinoGame.prototype._init = function() {
  this.dino       = { x:70, y:this.ground, w:30, h:40, vy:0, onGround:true, ducking:false, frame:0 };
  this.obstacles  = [];
  this.particles  = [];
  this.obstTimer  = 0;
  this.score      = 0;
  this.speed      = 4;
  this.tickCount  = 0;
  this.clouds     = [{x:100,y:30},{x:300,y:15},{x:500,y:40}];
};
DinoGame.prototype.start = function() {
  this._init(); this.state='running';
  if (this._raf) cancelAnimationFrame(this._raf);
  var self=this; this._raf=requestAnimationFrame(function(){ self._loop(); });
};
DinoGame.prototype.pause  = function() { if (this.state==='running') this.state='paused'; };
DinoGame.prototype.resume = function() {
  if (this.state==='paused') { this.state='running'; var self=this; this._raf=requestAnimationFrame(function(){ self._loop(); }); }
};
DinoGame.prototype.stop = function() { this.state='idle'; if (this._raf) cancelAnimationFrame(this._raf); };
DinoGame.prototype.jump = function() {
  if (this.state==='running' && this.dino.onGround) { this.dino.vy=-13; this.dino.onGround=false; }
};
DinoGame.prototype.duck = function(on) {
  if (this.state==='running') { this.dino.ducking=on; this.dino.h=on?20:40; }
};
DinoGame.prototype._loop = function() {
  if (this.state !== 'running') return;
  this._tick(); this._draw();
  var self=this; this._raf=requestAnimationFrame(function(){ self._loop(); });
};
DinoGame.prototype._tick = function() {
  var self=this; this.tickCount++;
  this.speed = 4 + this.score*0.015;
  var d=this.dino;
  d.vy += 0.7; d.y += d.vy;
  d.frame = Math.floor(this.tickCount/8)%2;
  var floorY = this.ground - (d.ducking ? 20 : 0);
  if (d.y >= floorY) { d.y=floorY; d.vy=0; d.onGround=true; }
  if (this.tickCount % 6 === 0) { this.score++; if(this.onScore) this.onScore(this.score,1); }
  this.obstTimer++;
  var minGap = Math.max(55, 85 - this.score*0.1);
  if (this.obstTimer > minGap) {
    this.obstTimer=0;
    if (Math.random() < 0.3) {
      var by = this.ground - 65 - Math.random()*35;
      this.obstacles.push({type:'bird',x:this.W,y:by,w:30,h:16,frame:0});
    } else {
      var h=30+Math.random()*25;
      this.obstacles.push({type:'cactus',x:this.W,y:this.ground-h+8,w:22,h:h});
    }
  }
  for (var i=0;i<this.obstacles.length;i++) {
    this.obstacles[i].x -= this.speed;
    if (this.obstacles[i].type==='bird') this.obstacles[i].frame=Math.floor(this.tickCount/10)%2;
  }
  this.obstacles = this.obstacles.filter(function(o){ return o.x > -60; });
  for (var i=0;i<this.obstacles.length;i++) {
    var o=this.obstacles[i];
    var dl=d.x-d.w/2+4, dr=d.x+d.w/2-4, dt=d.y-d.h+6;
    if (dr>o.x+4 && dl<o.x+o.w-4 && d.y>o.y+4 && dt<o.y+o.h-4) {
      this._burst(d.x, d.y-d.h/2, '#bf5fff');
      this.state='dead'; if(this.onDead) this.onDead(this.score,1); return;
    }
  }
  this.clouds.forEach(function(c){ c.x-=self.speed*0.2; if(c.x<-80) c.x=self.W+80; });
  this.particles = this.particles.filter(function(p){ return p.life>0; });
  this.particles.forEach(function(p){ p.x+=p.vx; p.y+=p.vy; p.vy+=0.2; p.life-=3; });
};
DinoGame.prototype._burst = function(x,y,color) {
  for (var i=0;i<8;i++) {
    var a=(i/8)*Math.PI*2;
    this.particles.push({x:x,y:y,vx:Math.cos(a)*4,vy:Math.sin(a)*4,color:color,life:60,size:3});
  }
};
DinoGame.prototype._draw = function() {
  var ctx=this.ctx, W=this.W, H=this.H, ground=this.ground, self=this;
  ctx.fillStyle='#07070f'; ctx.fillRect(0,0,W,H);
  this.clouds.forEach(function(c){
    ctx.fillStyle='#0f0f20';
    ctx.beginPath(); ctx.ellipse(c.x,c.y,40,14,0,0,Math.PI*2); ctx.fill();
    ctx.beginPath(); ctx.ellipse(c.x+20,c.y-8,25,12,0,0,Math.PI*2); ctx.fill();
  });
  ctx.strokeStyle='#bf5fff44'; ctx.lineWidth=2;
  ctx.beginPath(); ctx.moveTo(0,ground+10); ctx.lineTo(W,ground+10); ctx.stroke();
  ctx.fillStyle='#1a1a2e';
  var dotOffset = (this.tickCount*this.speed*0.5)%30;
  for (var x=dotOffset;x<W;x+=30) ctx.fillRect(x, ground+12, 15, 2);
  for (var i=0;i<this.obstacles.length;i++) {
    var o=this.obstacles[i];
    if (o.type==='cactus') {
      ctx.fillStyle='#4a2a6a'; ctx.strokeStyle='#bf5fff55'; ctx.lineWidth=1;
      ctx.fillRect(o.x+7,o.y,6,o.h); ctx.strokeRect(o.x+7,o.y,6,o.h);
      ctx.fillRect(o.x,o.y+8,8,5); ctx.fillRect(o.x,o.y+4,5,9);
      ctx.fillRect(o.x+13,o.y+10,8,5); ctx.fillRect(o.x+16,o.y+6,5,9);
    } else {
      ctx.fillStyle='#9a3fcc'; ctx.shadowColor='#bf5fff'; ctx.shadowBlur=6;
      ctx.fillRect(o.x,o.y+4,30,8);
      ctx.fillRect(o.x+5, o.frame===0?o.y-4:o.y+10, 20, 7);
      ctx.shadowBlur=0; ctx.fillStyle='#fff'; ctx.beginPath(); ctx.arc(o.x+26,o.y+6,3,0,Math.PI*2); ctx.fill();
    }
  }
  var d=this.dino;
  ctx.save(); ctx.shadowColor='#bf5fff'; ctx.shadowBlur=10; ctx.fillStyle='#bf5fff';
  var dx=d.x-d.w/2, dt=d.y-d.h;
  if (d.ducking) {
    ctx.fillRect(dx-10, d.y-20, 50, 20);
  } else {
    var legOff = d.onGround ? (d.frame===0?4:-4) : 0;
    ctx.fillRect(dx+6, d.y-12, 6, 12);
    ctx.fillRect(dx+16, d.y-12+legOff, 6, 12);
    ctx.fillRect(dx, dt+12, d.w, d.h-12);
    ctx.fillRect(dx+10, dt, 22, 20);
    ctx.shadowBlur=0; ctx.fillStyle='#fff'; ctx.fillRect(dx+26,dt+4,5,5);
    ctx.fillStyle='#000'; ctx.fillRect(dx+28,dt+5,3,3);
    ctx.fillStyle='#bf5fff'; ctx.fillRect(dx-10,dt+16,14,8);
  }
  ctx.restore();
  this.particles.forEach(function(p){
    ctx.save(); ctx.globalAlpha=p.life/60; ctx.fillStyle=p.color; ctx.shadowColor=p.color; ctx.shadowBlur=8;
    ctx.beginPath(); ctx.arc(p.x,p.y,p.size,0,Math.PI*2); ctx.fill(); ctx.restore();
  });
  ctx.fillStyle='#ffffff22'; ctx.font="10px 'Press Start 2P',monospace"; ctx.textAlign='right';
  ctx.fillText(this.score, W-16, 22);
};

// ═══════════════════════════════════════
//  APP CONTROLLER
// ═══════════════════════════════════════
var App = (function() {
  var user        = null;
  var bestScores  = { snake:0, flappy:0, dino:0 };
  var ranks       = { snake:null, flappy:null, dino:null };
  var snakeGame   = null;
  var flappyGame  = null;
  var dinoGame    = null;
  var _snakeSpeed = 150;

  function $(id) { return document.getElementById(id); }

  function toast(msg, isErr) {
    var el=$('toast'); el.textContent=msg; el.className='show'+(isErr?' err':'');
    clearTimeout(el._t); el._t=setTimeout(function(){ el.className=''; }, 3000);
  }

  function go(id) {
    if (id!=='s-game')   { if(snakeGame)  snakeGame.stop(); }
    if (id!=='s-flappy') { if(flappyGame) flappyGame.stop(); }
    if (id!=='s-dino')   { if(dinoGame)   dinoGame.stop(); }
    document.querySelectorAll('.screen').forEach(function(s){ s.classList.remove('active'); });
    $(id).classList.add('active');
    if (id==='s-home') refreshHome();
  }

  // overlays
  function showOv(id) {
    var screen=$(id).closest('.screen');
    screen.querySelectorAll('.ov').forEach(function(o){ o.classList.add('hide'); });
    $(id).classList.remove('hide');
  }
  function hideOvs(screenId) {
    $(screenId).querySelectorAll('.ov').forEach(function(o){ o.classList.add('hide'); });
  }

  // ── keyboard ──
  var SDIR = {
    ArrowUp:new Vec2(0,-1), ArrowDown:new Vec2(0,1),
    ArrowLeft:new Vec2(-1,0), ArrowRight:new Vec2(1,0),
    w:new Vec2(0,-1), s:new Vec2(0,1), a:new Vec2(-1,0), d:new Vec2(1,0),
    W:new Vec2(0,-1), S:new Vec2(0,1), A:new Vec2(-1,0), D:new Vec2(1,0),
  };
  document.addEventListener('keydown', function(e) {
    var onSnake  = $('s-game').classList.contains('active');
    var onFlappy = $('s-flappy').classList.contains('active');
    var onDino   = $('s-dino').classList.contains('active');
    if (onSnake) {
      if (SDIR[e.key]) { e.preventDefault(); if(snakeGame) snakeGame.snake.setDir(SDIR[e.key]); }
      if (e.key==='p'||e.key==='P') toggleSnakePause();
      if ((e.key==='r'||e.key==='R') && snakeGame && snakeGame.state!=='idle') startSnake();
    }
    if (onFlappy) {
      if (e.key===' ') { e.preventDefault(); if(flappyGame) flappyGame.flap(); }
      if (e.key==='p'||e.key==='P') toggleFlappyPause();
    }
    if (onDino) {
      if (e.key===' '||e.key==='ArrowUp') { e.preventDefault(); if(dinoGame) dinoGame.jump(); }
      if (e.key==='ArrowDown') { e.preventDefault(); if(dinoGame) dinoGame.duck(true); }
      if (e.key==='p'||e.key==='P') toggleDinoPause();
    }
  });
  document.addEventListener('keyup', function(e) {
    if (e.key==='ArrowDown' && dinoGame) dinoGame.duck(false);
  });
  document.getElementById('cv-flappy').addEventListener('click', function() {
    if (flappyGame) flappyGame.flap();
  });

  // ── auth ──
  async function login() {
    var u=$('l-user').value.trim(), p=$('l-pass').value, btn=$('l-btn'), err=$('l-err');
    if (!u||!p) { err.textContent='< FILL ALL FIELDS >'; return; }
    btn.disabled=true; btn.innerHTML='<span class="spin"></span>';
    try {
      var res=await API.login(u,p); API.setToken(res.token); user=res.user; $('l-pass').value=''; err.textContent=''; go('s-home');
    } catch(e) { err.textContent='< '+String(e).toUpperCase()+' >'; }
    finally { btn.disabled=false; btn.textContent='START GAME'; }
  }
  async function register() {
    var u=$('r-user').value.trim(),p=$('r-pass').value,p2=$('r-pass2').value,btn=$('r-btn'),err=$('r-err');
    if (!u||!p||!p2) { err.textContent='< FILL ALL FIELDS >'; return; }
    if (p!==p2) { err.textContent='< PASSWORDS DO NOT MATCH >'; return; }
    btn.disabled=true; btn.innerHTML='<span class="spin"></span>';
    try {
      var res=await API.register(u,p); API.setToken(res.token); user=res.user;
      ['r-user','r-pass','r-pass2'].forEach(function(id){ $(id).value=''; });
      err.textContent=''; go('s-home');
    } catch(e) { err.textContent='< '+String(e).toUpperCase()+' >'; }
    finally { btn.disabled=false; btn.textContent='CREATE ACCOUNT'; }
  }
  async function logout() {
    if(snakeGame) snakeGame.stop(); if(flappyGame) flappyGame.stop(); if(dinoGame) dinoGame.stop();
    try { await API.logout(); } catch(_) {}
    API.setToken(null);
    user=null; bestScores={snake:0,flappy:0,dino:0}; ranks={snake:null,flappy:null,dino:null};
    go('s-login');
  }

  // ── home ──
  function refreshHome() {
    if (!user) return;
    $('h-uname').textContent = user.username.toUpperCase();
    loadLeaderboard(); loadProfile();
  }

  async function loadLeaderboard() {
    try {
      var results = await Promise.all([API.leaderboard('snake',10), API.leaderboard('flappy',10), API.leaderboard('dino',10)]);
      var sRes=results[0], fRes=results[1], dRes=results[2];
      var map = {};
      function merge(entries, game) {
        entries.forEach(function(e) {
          if (!map[e.username]) map[e.username]={username:e.username,snake:0,flappy:0,dino:0,games:0};
          map[e.username][game]=e.best_score; map[e.username].games+=e.games_played;
        });
      }
      merge(sRes.entries,'snake'); merge(fRes.entries,'flappy'); merge(dRes.entries,'dino');
      var sorted=Object.values(map).sort(function(a,b){ return (b.snake+b.flappy+b.dino)-(a.snake+a.flappy+a.dino); });
      var rows = sorted.length ? sorted.map(function(e,i) {
        var n=i+1, cls=e.username===user.username?'me':'';
        var b=n<=3?'<span class="rbadge r'+n+'">'+n+'</span>':'<span class="rbadge ro">'+n+'</span>';
        return '<tr class="'+cls+'"><td>'+b+'</td><td>'+e.username.toUpperCase()+'</td>'
          +'<td><span style="color:var(--green);font-family:\'Press Start 2P\',monospace;font-size:10px">'+(e.snake||'--')+'</span></td>'
          +'<td><span style="color:var(--orange);font-family:\'Press Start 2P\',monospace;font-size:10px">'+(e.flappy||'--')+'</span></td>'
          +'<td><span style="color:var(--purple);font-family:\'Press Start 2P\',monospace;font-size:10px">'+(e.dino||'--')+'</span></td>'
          +'<td>'+e.games+'</td></tr>';
      }).join('') : '<tr><td colspan="6" style="text-align:center;padding:20px;color:var(--dim)">NO SCORES YET</td></tr>';
      $('lb-body').innerHTML=rows;
    } catch(_) { $('lb-body').innerHTML='<tr><td colspan="6" style="color:var(--red);padding:12px">Failed to load</td></tr>'; }
  }

  async function loadProfile() {
    try {
      var res=await API.profile();
      var s=res.stats.snake||{best_score:0,rank:null};
      var f=res.stats.flappy||{best_score:0,rank:null};
      var d=res.stats.dino||{best_score:0,rank:null};
      bestScores={snake:s.best_score,flappy:f.best_score,dino:d.best_score};
      ranks={snake:s.rank,flappy:f.rank,dino:d.rank};
      $('p-snake').textContent=s.best_score; $('p-flappy').textContent=f.best_score; $('p-dino').textContent=d.best_score;
      var icons={snake:'🐍',flappy:'🐦',dino:'🦕'};
      var html=res.recent.length ? res.recent.map(function(r){
        return '<div style="margin-bottom:6px;border-bottom:1px solid #0d0d18;padding-bottom:6px">'
          +(icons[r.game]||'🎮')
          +' <span style="font-size:11px">'+r.game.toUpperCase()+'</span>'
          +' <span style="color:var(--green)">'+r.score+' pts</span>'
          +'<span style="float:right;color:var(--dim);font-size:10px">'+new Date(r.played_at).toLocaleDateString()+'</span></div>';
      }).join('') : 'No games yet — go play!';
      $('p-recent').innerHTML=html;
    } catch(_) { $('p-recent').textContent='Failed to load profile.'; }
  }

  function tab(id) {
    document.querySelectorAll('.tab').forEach(function(t){ t.classList.remove('on'); });
    document.querySelectorAll('.tabpane').forEach(function(t){ t.classList.remove('on'); });
    $('t-'+id).classList.add('on'); $('tp-'+id).classList.add('on');
  }

  // ── SNAKE ──
  function playSnake() {
    go('s-game');
    var cv=$('cv-snake'); cv.width=cv.height=20*22;
    $('g-uname').textContent=user.username.toUpperCase();
    $('g-av').textContent=user.username[0].toUpperCase();
    $('g-rank').textContent=ranks.snake?'RANK #'+ranks.snake:'UNRANKED';
    $('g-best').textContent=bestScores.snake;
    snakeGame=new SnakeGame(cv,20,_snakeSpeed);
    snakeGame.onScore=function(sc,lv){ $('g-score').textContent=sc; $('g-level').textContent=lv; };
    snakeGame.onDead=async function(sc,lv) {
      showOv('sov-dead');
      $('s-go-txt').innerHTML='SCORE: <span style="color:var(--green)">'+sc+'</span>';
      try {
        var res=await API.submitScore('snake',sc,lv);
        bestScores.snake=res.best_score; ranks.snake=res.rank;
        $('g-best').textContent=res.best_score; $('g-rank').textContent='RANK #'+res.rank;
        $('s-go-txt').innerHTML='SCORE: <span style="color:var(--green)">'+sc+'</span><br>'+(sc>=res.best_score?'<span style="color:var(--yellow)">NEW BEST!</span>':'BEST: '+res.best_score);
      } catch(_){ toast('Score not saved',true); }
    };
    snakeGame._draw(); showOv('sov-start');
  }
  function startSnake()  { if(!snakeGame)return; hideOvs('s-game'); $('g-score').textContent='0'; $('g-level').textContent='1'; snakeGame.start(); }
  function resumeSnake() { hideOvs('s-game'); if(snakeGame) snakeGame.resume(); }
  function toggleSnakePause() {
    if (!snakeGame) return;
    if (snakeGame.state==='running') { snakeGame.pause(); showOv('sov-pause'); }
    else if (snakeGame.state==='paused') resumeSnake();
  }

  // ── FLAPPY ──
  function playFlappy() {
    go('s-flappy');
    var cv=$('cv-flappy'); cv.width=340; cv.height=480;
    $('f-uname').textContent=user.username.toUpperCase();
    $('f-av').textContent=user.username[0].toUpperCase();
    $('f-rank').textContent=ranks.flappy?'RANK #'+ranks.flappy:'UNRANKED';
    $('f-best').textContent=bestScores.flappy;
    flappyGame=new FlappyGame(cv);
    flappyGame.onScore=function(sc){ $('f-score').textContent=sc; };
    flappyGame.onDead=async function(sc) {
      showOv('fov-dead');
      $('f-go-txt').innerHTML='SCORE: <span style="color:var(--orange)">'+sc+'</span>';
      try {
        var res=await API.submitScore('flappy',sc,1);
        bestScores.flappy=res.best_score; ranks.flappy=res.rank;
        $('f-best').textContent=res.best_score; $('f-rank').textContent='RANK #'+res.rank;
        $('f-go-txt').innerHTML='SCORE: <span style="color:var(--orange)">'+sc+'</span><br>'+(sc>=res.best_score?'<span style="color:var(--yellow)">NEW BEST!</span>':'BEST: '+res.best_score);
      } catch(_){ toast('Score not saved',true); }
    };
    flappyGame._draw(); showOv('fov-start');
  }
  function startFlappy()  { if(!flappyGame)return; hideOvs('s-flappy'); $('f-score').textContent='0'; flappyGame.start(); }
  function resumeFlappy() { hideOvs('s-flappy'); if(flappyGame) flappyGame.resume(); }
  function toggleFlappyPause() {
    if (!flappyGame) return;
    if (flappyGame.state==='running') { flappyGame.pause(); showOv('fov-pause'); }
    else if (flappyGame.state==='paused') resumeFlappy();
  }

  // ── DINO ──
  function playDino() {
    go('s-dino');
    var cv=$('cv-dino'); cv.width=580; cv.height=200;
    $('d-uname').textContent=user.username.toUpperCase();
    $('d-av').textContent=user.username[0].toUpperCase();
    $('d-rank').textContent=ranks.dino?'RANK #'+ranks.dino:'UNRANKED';
    $('d-best').textContent=bestScores.dino;
    dinoGame=new DinoGame(cv);
    dinoGame.onScore=function(sc){ $('d-score').textContent=sc; };
    dinoGame.onDead=async function(sc) {
      showOv('dov-dead');
      $('d-go-txt').innerHTML='SCORE: <span style="color:var(--purple)">'+sc+'</span>';
      try {
        var res=await API.submitScore('dino',sc,1);
        bestScores.dino=res.best_score; ranks.dino=res.rank;
        $('d-best').textContent=res.best_score; $('d-rank').textContent='RANK #'+res.rank;
        $('d-go-txt').innerHTML='SCORE: <span style="color:var(--purple)">'+sc+'</span><br>'+(sc>=res.best_score?'<span style="color:var(--yellow)">NEW BEST!</span>':'BEST: '+res.best_score);
      } catch(_){ toast('Score not saved',true); }
    };
    dinoGame._draw(); showOv('dov-start');
  }
  function startDino()  { if(!dinoGame)return; hideOvs('s-dino'); $('d-score').textContent='0'; dinoGame.start(); }
  function resumeDino() { hideOvs('s-dino'); if(dinoGame) dinoGame.resume(); }
  function toggleDinoPause() {
    if (!dinoGame) return;
    if (dinoGame.state==='running') { dinoGame.pause(); showOv('dov-pause'); }
    else if (dinoGame.state==='paused') resumeDino();
  }

  function snakeSpeed(btn) {
    btn.closest('.speeds').querySelectorAll('.sp').forEach(function(b){ b.classList.remove('on'); });
    btn.classList.add('on');
    _snakeSpeed=parseInt(btn.dataset.ms);
    if(snakeGame) snakeGame.setSpeed(_snakeSpeed);
  }

  // enter keys
  $('l-pass').addEventListener('keydown', function(e){ if(e.key==='Enter') login(); });
  $('l-user').addEventListener('keydown', function(e){ if(e.key==='Enter') login(); });
  $('r-pass2').addEventListener('keydown', function(e){ if(e.key==='Enter') register(); });

  // boot — check if PHP session already exists
  API.session()
    .then(function(res){ if(res.user){ user=res.user; go('s-home'); } else go('s-login'); })
    .catch(function(){ go('s-login'); });

  return { go:go, login:login, register:register, logout:logout,
           playSnake:playSnake, playFlappy:playFlappy, playDino:playDino,
           startSnake:startSnake, resumeSnake:resumeSnake,
           startFlappy:startFlappy, resumeFlappy:resumeFlappy,
           startDino:startDino, resumeDino:resumeDino,
           tab:tab, snakeSpeed:snakeSpeed };
})();
