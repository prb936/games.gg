<?php
require_once __DIR__ . '/helpers.php';
$userId = auth();
if ($userId <= 0) fail('Invalid user', 401);              
$b      = body();
$game   = trim($b['game']  ?? '');
$score  = (int) ($b['score'] ?? 0);
$level  = (int) ($b['level'] ?? 1);
$allowed = ['snake', 'flappy', 'dino'];
if (!in_array($game, $allowed, true)) fail('Unknown game');
if ($score < 0) fail('Score cannot be negative');
$db = getDB();

// 1. Insert raw score
$db->prepare('INSERT INTO scores (user_id, game, score, level) VALUES (?, ?, ?, ?)')
   ->execute([$userId, $game, $score, $level]);

// 2. Get this user's all-time best for this game
$s = $db->prepare('SELECT MAX(score) AS best FROM scores WHERE user_id = ? AND game = ?');
$s->execute([$userId, $game]);
$best = (int) $s->fetchColumn();

// 3. Get username for leaderboard
$u = $db->prepare('SELECT username FROM users WHERE id = ?');
$u->execute([$userId]);
$username = $u->fetchColumn();

// 4. Upsert leaderboard — keeps it in sync automatically
$db->prepare('
    INSERT INTO leaderboard (user_id, username, game, best_score, games_played)
    VALUES (?, ?, ?, ?, 1)
    ON DUPLICATE KEY UPDATE
        best_score   = GREATEST(best_score, VALUES(best_score)),
        games_played = games_played + 1,
        username     = VALUES(username)
')->execute([$userId, $username, $game, $best]);

// 5. Calculate rank
$r = $db->prepare('SELECT COUNT(*) + 1 AS rank FROM leaderboard WHERE game = ? AND best_score > ?');
$r->execute([$game, $best]);
$rank = (int) $r->fetchColumn();

ok(array('best_score' => $best, 'rank' => $rank));