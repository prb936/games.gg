<?php
require_once __DIR__ . '/helpers.php';
$game  = trim($_GET['game']  ?? 'snake');
$limit = min((int) ($_GET['limit'] ?? 10), 100);
$allowed = ['snake', 'flappy', 'dino'];
if (!in_array($game, $allowed, true)) fail('Unknown game');
$db = getDB();
$s  = $db->prepare('SELECT username, best_score, games_played FROM leaderboard WHERE game = ? ORDER BY best_score DESC LIMIT ' . $limit);
$s->execute([$game]);
$rows = $s->fetchAll();
$entries = array();
foreach ($rows as $r) {
    $entries[] = array(
        'username'     => $r['username'],
        'best_score'   => (int) $r['best_score'],
        'games_played' => (int) $r['games_played'],
    );
}
ok(array('entries' => $entries));