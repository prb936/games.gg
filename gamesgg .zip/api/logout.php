<?php
// POST /api/logout.php
// Clears the token from DB so it can't be reused
require_once __DIR__ . '/helpers.php';

$body  = json_decode(file_get_contents('php://input'), true);
$token = $body['_token'] ?? null;
if ($token) {
    $db = getDB();
    $db->prepare('UPDATE users SET auth_token = NULL WHERE auth_token = ?')
       ->execute([$token]);
}
ok(['message' => 'Logged out']);
