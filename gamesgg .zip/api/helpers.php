<?php
set_time_limit(10);
require_once __DIR__ . '/../config/db.php';
header('Content-Type: application/json');
header('X-Content-Type-Options: nosniff');

function ok(array $data = []): void {
    echo json_encode(array_merge(['ok' => true], $data));
    exit;
}
function fail(string $msg, int $status = 400): void {
    http_response_code($status);
    echo json_encode(['ok' => false, 'error' => $msg]);
    exit;
}
function body(): array {
    $data = json_decode(file_get_contents('php://input'), true);
    if (!is_array($data)) fail('Expected JSON body');
    return $data;
}

// Token auth — InfinityFree strips Authorization headers on free hosting.
// So we pass the token as _token field in POST body, or ?_token= in GET query.
function auth(): int {
    // Check POST body first
    $raw = file_get_contents('php://input');
    $body = json_decode($raw, true);
    $token = $body['_token'] ?? null;
    // Fall back to GET param for GET requests
    if (!$token) $token = $_GET['_token'] ?? null;
    if (!$token) fail('Not logged in', 401);
    $db = getDB();
    $s  = $db->prepare('SELECT id FROM users WHERE auth_token = ?');
    $s->execute([$token]);
    $row = $s->fetch();
    if (!$row) fail('Not logged in', 401);
    return (int) $row['id'];
}
