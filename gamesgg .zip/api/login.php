<?php
// POST /api/login.php
// Body: { "username": "alice", "password": "1234" }
// Returns token which JS stores in localStorage
require_once __DIR__ . '/helpers.php';

$b        = body();
$username = strtolower(trim($b['username'] ?? ''));
$password = $b['password'] ?? '';

if (!$username || !$password) fail('Fill in all fields');

$db = getDB();
$s  = $db->prepare('SELECT id, username, password_hash FROM users WHERE username = ?');
$s->execute([$username]);
$user = $s->fetch();

if (!$user || !password_verify($password, $user['password_hash'])) {
    fail('Wrong username or password', 401);
}

// Generate a secure random token and save it to the DB
$token = bin2hex(random_bytes(32));
$db->prepare('UPDATE users SET auth_token = ? WHERE id = ?')
   ->execute([$token, $user['id']]);

ok(['user' => ['id' => (int) $user['id'], 'username' => $user['username']], 'token' => $token]);
