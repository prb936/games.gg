<?php
// GET /api/session.php?_token=xxx
// Called on page load — JS sends stored token as query param, we verify and return user info
require_once __DIR__ . '/helpers.php';

$token = $_GET['_token'] ?? null;
if (!$token) { ok(['user' => null]); }

$db = getDB();
$s  = $db->prepare('SELECT id, username FROM users WHERE auth_token = ?');
$s->execute([$token]);
$user = $s->fetch();

if (!$user) { ok(['user' => null]); }
ok(['user' => ['id' => (int) $user['id'], 'username' => $user['username']]]);
