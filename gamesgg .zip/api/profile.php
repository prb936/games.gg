<?php
// GET /api/profile.php  (own profile, needs session)
require_once __DIR__ . '/helpers.php';

$userId = auth();
$db     = getDB();

// Best score + games played per game
$s = $db->prepare('
    SELECT game, MAX(score) AS best_score, COUNT(*) AS games_played
    FROM scores WHERE user_id = ?
    GROUP BY game
');
$s->execute([$userId]);
$stats = [];
foreach ($s->fetchAll() as $row) {
    $stats[$row['game']] = [
        'best_score'   => (int) $row['best_score'],
        'games_played' => (int) $row['games_played'],
        'rank'         => null,
    ];
}

// Rank per game
$rankStmt = $db->prepare('
    SELECT COUNT(*) + 1 FROM leaderboard
    WHERE game = ? AND best_score > ?
');
foreach ($stats as $game => &$data) {
    $rankStmt->execute([$game, $data['best_score']]);
    $data['rank'] = (int) $rankStmt->fetchColumn();
}
unset($data);

// 10 most recent scores across all games
$r = $db->prepare('
    SELECT game, score, level, played_at
    FROM scores WHERE user_id = ?
    ORDER BY played_at DESC LIMIT 10
');
$r->execute([$userId]);
$recent = array_map(fn($row) => [
    'game'      => $row['game'],
    'score'     => (int) $row['score'],
    'level'     => (int) $row['level'],
    'played_at' => $row['played_at'],
], $r->fetchAll());

ok(['stats' => $stats, 'recent' => $recent]);
