<?php
// POST /api/register.php
// Body: { "username": "alice", "password": "1234" }
// Returns token which JS stores in localStorage
require_once __DIR__ . '/helpers.php';

$b        = body();
$username = strtolower(trim($b['username'] ?? ''));
$password = $b['password'] ?? '';

if (strlen($username) < 3)  fail('Username must be at least 3 characters');
if (strlen($username) > 32) fail('Username too long');
if (strlen($password) < 4)  fail('Password must be at least 4 characters');
if (!preg_match('/^[a-z0-9_]+$/', $username)) fail('Username: letters, numbers and _ only');

$db = getDB();

$s = $db->prepare('SELECT id FROM users WHERE username = ?');
$s->execute([$username]);
if ($s->fetch()) fail('Username already taken');

// Generate token at registration so user is immediately logged in
$token = bin2hex(random_bytes(32));
$hash  = password_hash($password, PASSWORD_BCRYPT);
$s     = $db->prepare('INSERT INTO users (username, password_hash, auth_token) VALUES (?, ?, ?)');
$s->execute([$username, $hash, $token]);
$id = (int) $db->lastInsertId();

ok(['user' => ['id' => $id, 'username' => $username], 'token' => $token]);
