<?php
define('DB_HOST', 'sql102.infinityfree.com');
define('DB_NAME', 'if0_41336196_arcade_infinityfree');
define('DB_USER', 'if0_41336196');
define('DB_PASS', 'Qy5rraJKG1');

function getDB(): PDO {
    static $pdo = null;
    if ($pdo !== null) return $pdo;
    try {
        $pdo = new PDO(
            "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8",
            DB_USER,
            DB_PASS,
            [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_TIMEOUT            => 5,   // fail fast, don't hang
            ]
        );
    } catch (PDOException $e) {
        http_response_code(503);
        header('Content-Type: application/json');
        echo json_encode(['ok' => false, 'error' => 'Database unavailable. Please try again.']);
        exit;
    }
    return $pdo;
}